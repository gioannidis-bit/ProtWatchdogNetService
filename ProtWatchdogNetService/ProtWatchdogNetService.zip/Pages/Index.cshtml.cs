
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProtWatchdog.Pages;

public class IndexModel : PageModel
{
    public void OnGet() { }
}
